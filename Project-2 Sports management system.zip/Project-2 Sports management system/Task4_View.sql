/*
**Name: Mishwaben Rakeshkumar Patel and Vaibhavi Honagekar 
**Date: 04/25/2024
** History 
** Date Created    Comments 
** 01/21/2024      Creating Tables
** 01/28/2024      Populating Tables
** 02/04/2024      Create Views
** 02/09/2024      Scripting
** 02/18/2024      Stored Procedures
** 02/24/2024      User-Defined Functions
** 02/28/2024      Cursor
** 03/16/2024      Triggers
** 03/20/2024      Transaction
** 03/28/2024      Security
** 04/25/2024      Final Submission
*/

/*VIEW1*/
CREATE VIEW PlayerStats AS
SELECT
    s.match_id,
    s.athlete_id,
    a.first_name,
    a.last_name,
    s.goals_scored,
    s.assists,
    s.yellow_cards,
    s.red_cards
FROM
    [Statistics] s
JOIN
    Athletes a ON s.athlete_id = a.athlete_id;

SELECT * FROM PlayerStats;

/*VIEW2*/

CREATE VIEW TeamStandings AS
SELECT
    st.tournament_id,
    st.team_id,
    t.team_name,
    st.position,
    st.points
FROM
    Standings st
JOIN
    Teams t ON st.team_id = t.team_id;
SELECT * FROM TeamStandings;

/*VIEW3*/

CREATE VIEW MatchResults AS
SELECT
    m.match_id,
    m.date,
    m.location,
    home.team_name AS home_team,
    away.team_name AS away_team,
    CASE
        WHEN m.winner_id = m.home_team_id THEN 'Home'
        ELSE 'Away'
    END AS winning_side
FROM
    Matches m
JOIN
    Teams home ON m.home_team_id = home.team_id
JOIN
    Teams away ON m.away_team_id = away.team_id;

SELECT * FROM MatchResults;