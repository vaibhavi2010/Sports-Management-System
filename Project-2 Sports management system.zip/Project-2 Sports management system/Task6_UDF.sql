/*
**Name: Vaibhavi Honagekar and Mishwaben Rakeshkumar Patel
**Date: 04/25/2024
** History 
** Date Created    Comments 
** 01/21/2024      Creating Tables
** 01/28/2024      Populating Tables
** 02/04/2024      Create Views
** 02/09/2024      Scripting
** 02/18/2024      Stored Procedures
** 02/24/2024      User-Defined Functions
** 02/28/2024      Cursor
** 03/16/2024      Triggers
** 03/20/2024      Transaction
** 03/28/2024      Security
** 04/25/2024      Final Submission
*/

-- Drop stored procedure if exists
IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'GetAthletesByTeamID')
BEGIN
    DROP PROCEDURE GetAthletesByTeamID
END
GO

-- Create stored procedure to retrieve athletes by team ID
CREATE PROCEDURE GetAthletesByTeamID
    @teamID INT
AS
BEGIN
    SELECT *
    FROM Athletes
    WHERE team_id = @teamID;
END
GO

-- Drop user-defined function if exists
IF EXISTS (SELECT * FROM sys.objects WHERE type = 'FN' AND name = 'CalculateAge')
BEGIN
    DROP FUNCTION CalculateAge
END
GO

-- Create user-defined function to calculate age
CREATE FUNCTION CalculateAge 
(
    @dob DATE
)
RETURNS INT
AS
BEGIN
    DECLARE @age INT;
    SET @age = DATEDIFF(YEAR, @dob, GETDATE()) - 
               CASE
                   WHEN (MONTH(@dob) > MONTH(GETDATE())) OR (MONTH(@dob) = MONTH(GETDATE()) AND DAY(@dob) > DAY(GETDATE())) THEN 1
                   ELSE 0
               END;
    RETURN @age;
END
GO

-- Execute the stored procedure to retrieve athletes by team ID
EXEC GetAthletesByTeamID @teamID = 1;

-- Using the user-defined function to calculate the age of an athlete
SELECT first_name, last_name, date_of_birth, dbo.CalculateAge(date_of_birth) AS age
FROM Athletes;
