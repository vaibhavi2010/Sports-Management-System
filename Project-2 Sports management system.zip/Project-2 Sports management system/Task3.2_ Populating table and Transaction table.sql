/*
**Name: Mishwaben Rakeshkumar Patel and Vaibhavi Honagekar 
**Date: 04/25/2024
** History 
** Date Created    Comments 
** 01/21/2024      Creating Tables
** 01/28/2024      Populating Tables
** 02/04/2024      Create Views
** 02/09/2024      Scripting
** 02/18/2024      Stored Procedures
** 02/24/2024      User-Defined Functions
** 02/28/2024      Cursor
** 03/16/2024      Triggers
** 03/20/2024      Transaction
** 03/28/2024      Security
** 04/25/2024      Final Submission
*/

-- Populate Teams dimension table
INSERT INTO Teams (team_id, team_name, sports, established_date, coach_id, home_stadium)
VALUES
(1, 'Team Alpha', 'Football', '2010-01-01', 1, 'Alpha Stadium'),
(2, 'Team Bravo', 'Football', '2012-03-15', 2, 'Bravo Stadium'),
(3, 'Team Charlie', 'Basketball', '2008-07-20', 3, 'Charlie Arena'),
(4, 'Team Delta', 'Basketball', '2011-09-10', 4, 'Delta Arena'),
(5, 'Team Echo', 'Soccer', '2013-05-28', 5, 'Echo Field'),
(6, 'Team Foxtrot', 'Soccer', '2009-11-12', 6, 'Foxtrot Field'),
(7, 'Team Golf', 'Baseball', '2014-02-17', 7, 'Golf Park'),
(8, 'Team Hotel', 'Baseball', '2010-08-05', 8, 'Hotel Park'),
(9, 'Team India', 'Cricket', '2015-04-23', 9, 'India Cricket Ground'),
(10, 'Team Juliet', 'Cricket', '2011-10-30', 10, 'Juliet Cricket Ground');

-- Populate Athletes dimension table
INSERT INTO Athletes (athlete_id, first_name, last_name, date_of_birth, nationality, team_id)
VALUES
(1, 'John', 'Doe', '1990-05-15', 'American', 1),
(2, 'Emma', 'Smith', '1992-08-20', 'British', 1),
(3, 'Michael', 'Johnson', '1988-03-10', 'Canadian', 2),
(4, 'Sophia', 'Garcia', '1991-11-25', 'Spanish', 2),
(5, 'David', 'Martinez', '1989-07-03', 'French', 3),
(6, 'Emily', 'Brown', '1993-04-12', 'German', 3),
(7, 'Daniel', 'Jones', '1990-09-30', 'Italian', 4),
(8, 'Olivia', 'Wilson', '1987-12-18', 'Russian', 4),
(9, 'James', 'Taylor', '1994-02-05', 'Chinese', 5),
(10, 'Isabella', 'Lopez', '1996-06-22', 'Japanese', 5);

-- Populate Tournaments dimension table
INSERT INTO Tournaments (tournament_id, tournament_name, sport, start_date, end_date)
VALUES
(1, 'Football Championship', 'Football', '2023-01-01', '2023-12-31'),
(2, 'Basketball Tournament', 'Basketball', '2023-02-01', '2023-11-30'),
(3, 'Soccer Cup', 'Soccer', '2023-03-01', '2023-10-31'),
(4, 'Baseball League', 'Baseball', '2023-04-01', '2023-09-30'),
(5, 'Cricket Cup', 'Cricket', '2023-05-01', '2023-08-31'),
(6, 'Tennis Open', 'Tennis', '2023-06-01', '2023-07-31'),
(7, 'Rugby Championship', 'Rugby', '2023-07-01', '2023-06-30'),
(8, 'Hockey Cup', 'Hockey', '2023-08-01', '2023-05-31'),
(9, 'Volleyball League', 'Volleyball', '2023-09-01', '2023-04-30'),
(10, 'Badminton Open', 'Badminton', '2023-10-01', '2023-03-31');

-- Populate Coaches dimension table
INSERT INTO Coaches (coach_id, first_name, last_name, date_of_birth, nationality, team_id)
VALUES
(1, 'John', 'Smith', '1975-04-15', 'American', 1),
(2, 'Emma', 'Johnson', '1980-08-20', 'British', 2),
(3, 'Michael', 'Williams', '1978-03-10', 'Canadian', 3),
(4, 'Sophia', 'Brown', '1982-11-25', 'Spanish', 4),
(5, 'David', 'Jones', '1979-07-03', 'French', 5),
(6, 'Emily', 'Taylor', '1984-04-12', 'German', 6),
(7, 'Daniel', 'Wilson', '1976-09-30', 'Italian', 7),
(8, 'Olivia', 'Lopez', '1981-12-18', 'Russian', 8),
(9, 'James', 'Martinez', '1977-02-05', 'Chinese', 9),
(10, 'Isabella', 'Garcia', '1985-06-22', 'Japanese', 10);



-- Populate Matches transactional table
INSERT INTO Matches (match_id, date, location, home_team_id, away_team_id, winner_id, loser_id, tournament_id)
VALUES
(1, '2024-01-01', 'Stadium A', 1, 2, 1, 2, 1),
(2, '2024-01-01', 'Stadium B', 3, 4, 3, 4, 1),
(3, '2024-01-02', 'Stadium C', 5, 6, 5, 6, 1),
(4, '2024-01-02', 'Stadium D', 7, 8, 8, 7, 1),
(5, '2024-01-03', 'Stadium E', 9, 10, 9, 10, 1),
(6, '2024-01-03', 'Stadium F', 11, 12, 12, 11, 1),
(7, '2024-01-04', 'Stadium G', 13, 14, 13, 14, 1),
(8, '2024-01-04', 'Stadium H', 15, 16, 15, 16, 1),
(9, '2024-01-05', 'Stadium I', 17, 18, 17, 18, 1),
(10, '2024-01-05', 'Stadium J', 19, 20, 19, 20, 1),
(11, '2024-01-06', 'Stadium K', 21, 22, 21, 22, 1),
(12, '2024-01-06', 'Stadium L', 23, 24, 24, 23, 1),
(13, '2024-01-07', 'Stadium M', 25, 1, 25, 1, 1),
(14, '2024-01-07', 'Stadium N', 2, 3, 1, 1, 1),
(15, '2024-01-08', 'Stadium O', 4, 5, 4, 5, 1),
(16, '2024-01-08', 'Stadium P', 6, 7, 7, 6, 1),
(17, '2024-01-09', 'Stadium Q', 8, 9, 8, 9, 1),
(18, '2024-01-09', 'Stadium R', 10, 11, 11, 10, 1),
(19, '2024-01-10', 'Stadium S', 12, 13, 12, 13, 1),
(20, '2024-01-10', 'Stadium T', 14, 15, 15, 14, 1),

-- Populate Stadiums transactional table
INSERT INTO Stadiums (stadium_id, stadium_name, city, country, capacity)
VALUES
(1, 'Alpha Stadium', 'New York', 'USA', 50000),
(2, 'Bravo Stadium', 'London', 'UK', 45000),
(3, 'Charlie Arena', 'Toronto', 'Canada', 40000),
(4, 'Delta Arena', 'Madrid', 'Spain', 55000),
(5, 'Echo Field', 'Paris', 'France', 60000),
(6, 'Foxtrot Field', 'Berlin', 'Germany', 52000),
(7, 'Golf Park', 'Rome', 'Italy', 48000),
(8, 'Hotel Park', 'Moscow', 'Russia', 53000),
(9, 'India Cricket Ground', 'Mumbai', 'India', 70000),
(10, 'Juliet Cricket Ground', 'Tokyo', 'Japan', 65000);

INSERT INTO [Statistics] (stat_id, match_id, athlete_id, goals_scored, assists, yellow_cards, red_cards) VALUES
(1, 1, 1, 3, 2, 0, 0),
(2, 2, 2, 1, 0, 1, 0),
(3, 3, 2, 0, 3, 2, 0),
(4, 4, 4, 2, 2, 0, 1),
(5, 5, 5, 1, 1, 0, 0),
(6, 6, 6, 4, 0, 1, 0),
(7, 7, 7, 0, 0, 0, 1),
(8, 8, 8, 2, 0, 2, 0),
(9, 9, 9, 3, 1, 1, 0),
(10, 10, 21, 1, 2, 0, 0),
(11, 11, 11, 0, 0, 2, 1),
(12, 12, 12, 1, 1, 1, 0),
(13, 13, 13, 2, 3, 0, 0),
(14, 14, 14, 1, 0, 0, 0),
(15, 15, 15, 0, 2, 1, 0),
(16, 16, 16, 3, 1, 0, 0),
(17, 17, 17, 2, 0, 0, 1),
(18, 18, 18, 0, 0, 3, 0),
(19, 19, 19, 1, 2, 0, 0),
(20, 20, 20, 0, 1, 2, 0);

SELECT * FROM Athletes;
-- Display contents of the Teams table
SELECT * FROM Teams;
-- Display contents of the Matches table
SELECT * FROM Matches;
-- Display contents of the Tournaments table
SELECT * FROM Tournaments;
-- Display contents of the Statistics table
SELECT * FROM [Statistics];
-- Display contents of the Coaches table
SELECT * FROM Coaches;
-- Display contents of the Stadiums table
SELECT * FROM Stadiums;
-- Display contents of the Leagues table
SELECT * FROM Leagues;
-- Display contents of the Standings table
SELECT * FROM Standings;
