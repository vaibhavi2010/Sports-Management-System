/*
**Name: Vaibhavi Honagekar and Mishwaben Rakeshkumar Patel
**Date: 04/25/2024
** History 
** Date Created    Comments 
** 01/21/2024      Creating Tables
** 01/28/2024      Populating Tables
** 02/04/2024      Create Views
** 02/09/2024      Scripting
** 02/18/2024      Stored Procedures
** 02/24/2024      User-Defined Functions
** 02/28/2024      Cursor
** 03/16/2024      Triggers
** 03/20/2024      Transaction
** 03/28/2024      Security
** 04/24/2024      Final Submission
*/


-- Inserting data into Teams table (No dependencies)
INSERT INTO Teams (team_id, team_name, sports, established_date, coach_id, home_stadium)
VALUES
(1, 'Team Alpha', 'Football', '2010-01-01', 1, 'Alpha Stadium'),
(2, 'Team Bravo', 'Football', '2012-03-15', 2, 'Bravo Stadium'),
(3, 'Team Charlie', 'Basketball', '2008-07-20', 3, 'Charlie Arena'),
(4, 'Team Delta', 'Basketball', '2011-09-10', 4, 'Delta Arena'),
(5, 'Team Echo', 'Soccer', '2013-05-28', 5, 'Echo Field'),
(6, 'Team Foxtrot', 'Soccer', '2009-11-12', 6, 'Foxtrot Field'),
(7, 'Team Golf', 'Baseball', '2014-02-17', 7, 'Golf Park'),
(8, 'Team Hotel', 'Baseball', '2010-08-05', 8, 'Hotel Park'),
(9, 'Team India', 'Cricket', '2015-04-23', 9, 'India Cricket Ground'),
(10, 'Team Juliet', 'Cricket', '2011-10-30', 10, 'Juliet Cricket Ground'),
(11, 'Team Kilo', 'Tennis', '2016-06-07', 11, 'Kilo Tennis Center'),
(12, 'Team Lima', 'Tennis', '2012-12-14', 12, 'Lima Tennis Center'),
(13, 'Team Mike', 'Rugby', '2017-09-03', 13, 'Mike Stadium'),
(14, 'Team November', 'Rugby', '2013-11-20', 14, 'November Stadium'),
(15, 'Team Oscar', 'Hockey', '2018-08-11', 15, 'Oscar Arena'),
(16, 'Team Papa', 'Hockey', '2014-10-25', 16, 'Papa Arena'),
(17, 'Team Quebec', 'Volleyball', '2019-07-19', 17, 'Quebec Arena'),
(18, 'Team Romeo', 'Volleyball', '2015-12-03', 18, 'Romeo Arena'),
(19, 'Team Sierra', 'Badminton', '2020-04-05', 19, 'Sierra Hall'),
(20, 'Team Tango', 'Badminton', '2016-09-28', 20, 'Tango Hall'),
(21, 'Team Uniform', 'Golf', '2021-01-12', 21, 'Uniform Golf Course'),
(22, 'Team Victor', 'Golf', '2017-03-07', 22, 'Victor Golf Course'),
(23, 'Team Whiskey', 'Swimming', '2022-02-25', 23, 'Whiskey Pool'),
(24, 'Team X-ray', 'Swimming', '2018-06-14', 24, 'X-ray Pool'),
(25, 'Team Yankee', 'Athletics', '2023-03-10', 25, 'Yankee Track');

-- Inserting data into Athletes table (Depends on Teams)
INSERT INTO Athletes (athlete_id, first_name, last_name, date_of_birth, nationality, team_id)
VALUES
(1, 'John', 'Doe', '1990-05-15', 'American', 1),
(2, 'Emma', 'Smith', '1992-08-20', 'British', 1),
(3, 'Michael', 'Johnson', '1988-03-10', 'Canadian', 2),
(4, 'Sophia', 'Garcia', '1991-11-25', 'Spanish', 2),
(5, 'David', 'Martinez', '1989-07-03', 'French', 3),
(6, 'Emily', 'Brown', '1993-04-12', 'German', 3),
(7, 'Daniel', 'Jones', '1990-09-30', 'Italian', 4),
(8, 'Olivia', 'Wilson', '1987-12-18', 'Russian', 4),
(9, 'James', 'Taylor', '1994-02-05', 'Chinese', 5),
(10, 'Isabella', 'Lopez', '1996-06-22', 'Japanese', 5),
(11, 'William', 'Harris', '1991-08-07', 'Swedish', 6),
(12, 'Ava', 'Clark', '1993-10-15', 'Australian', 6),
(13, 'Alexander', 'Lewis', '1992-03-28', 'Mexican', 7),
(14, 'Mia', 'Lee', '1990-06-09', 'Dutch', 7),
(15, 'Ethan', 'Walker', '1995-01-19', 'Belgian', 8),
(16, 'Charlotte', 'Green', '1988-04-27', 'Irish', 8),
(17, 'Ryan', 'Martin', '1993-09-02', 'Portuguese', 9),
(18, 'Sophie', 'Hill', '1989-12-11', 'Greek', 9),
(19, 'Benjamin', 'Young', '1994-07-01', 'Turkish', 10),
(20, 'Amelia', 'King', '1991-05-14', 'Norwegian', 10),
(21, 'Samuel', 'Allen', '1986-11-28', 'Polish', 11),
(22, 'Chloe', 'Scott', '1997-03-25', 'Finnish', 11),
(23, 'Joseph', 'Wright', '1990-02-08', 'Vietnamese', 12),
(24, 'Grace', 'Adams', '1992-08-17', 'Thai', 12),
(25, 'Jacob', 'Hall', '1987-06-16', 'Malaysian', 13),
(26, 'Zoe', 'Baker', '1996-04-23', 'Singaporean', 13),
(27, 'Matthew', 'Nelson', '1993-12-05', 'Indonesian', 14),
(28, 'Madison', 'Evans', '1990-10-30', 'Filipino', 14),
(29, 'David', 'White', '1991-07-07', 'Indian', 15);


-- Inserting data into the Tournaments table
INSERT INTO Tournaments (tournament_id, tournament_name, sport, start_date, end_date)
VALUES
(1, 'Football Championship', 'Football', '2023-01-01', '2023-12-31'),
(2, 'Basketball Tournament', 'Basketball', '2023-02-01', '2023-11-30'),
(3, 'Soccer Cup', 'Soccer', '2023-03-01', '2023-10-31'),
(4, 'Baseball League', 'Baseball', '2023-04-01', '2023-09-30'),
(5, 'Cricket Cup', 'Cricket', '2023-05-01', '2023-08-31'),
(6, 'Tennis Open', 'Tennis', '2023-06-01', '2023-07-31'),
(7, 'Rugby Championship', 'Rugby', '2023-07-01', '2023-06-30'),
(8, 'Hockey Cup', 'Hockey', '2023-08-01', '2023-05-31'),
(9, 'Volleyball League', 'Volleyball', '2023-09-01', '2023-04-30'),
(10, 'Badminton Open', 'Badminton', '2023-10-01', '2023-03-31'),
(11, 'Golf Tournament', 'Golf', '2023-11-01', '2023-02-28'),
(12, 'Swimming Cup', 'Swimming', '2023-12-01', '2023-01-31'),
(13, 'Athletics Championship', 'Athletics', '2024-01-01', '2024-12-31'),
(14, 'Table Tennis Open', 'Table Tennis', '2024-02-01', '2024-11-30'),
(15, 'Boxing Tournament', 'Boxing', '2024-03-01', '2024-10-31'),
(16, 'Martial Arts Championship', 'Martial Arts', '2024-04-01', '2024-09-30'),
(17, 'Cycling Cup', 'Cycling', '2024-05-01', '2024-08-31'),
(18, 'Gymnastics Championship', 'Gymnastics', '2024-06-01', '2024-07-31'),
(19, 'Wrestling Open', 'Wrestling', '2024-07-01', '2024-06-30'),
(20, 'Archery Tournament', 'Archery', '2024-08-01', '2024-05-31'),
(21, 'Fencing Cup', 'Fencing', '2024-09-01', '2024-04-30'),
(22, 'Rowing Championship', 'Rowing', '2024-10-01', '2024-03-31'),
(23, 'Canoeing Cup', 'Canoeing', '2024-11-01', '2024-02-29'),
(24, 'Sailing Tournament', 'Sailing', '2024-12-01', '2024-01-31'),
(25, 'Triathlon Championship', 'Triathlon', '2025-01-01', '2025-12-31'),
(26, 'Equestrian Cup', 'Equestrian', '2025-02-01', '2025-11-30'),
(27, 'Surfing Open', 'Surfing', '2025-03-01', '2025-10-31'),
(28, 'Skateboarding Championship', 'Skateboarding', '2025-04-01', '2025-09-30'),
(29, 'Snowboarding Cup', 'Snowboarding', '2025-05-01', '2025-08-31'),
(30, 'Skiing Tournament', 'Skiing', '2025-06-01', '2025-07-31'),
(31, 'Mountaineering Cup', 'Mountaineering', '2025-07-01', '2025-06-30'),
(32, 'Golf Tournament', 'Golf', '2025-08-01', '2025-05-31'),
(33, 'Cycling Cup', 'Cycling', '2025-09-01', '2025-04-30'),
(34, 'Marathon Championship', 'Marathon', '2025-10-01', '2025-03-31'),
(35, 'Triathlon Championship', 'Triathlon', '2025-11-01', '2025-02-28');

-- Inserting data into the Coaches table
INSERT INTO Coaches (coach_id, first_name, last_name, date_of_birth, nationality, team_id)
VALUES
(1, 'John', 'Smith', '1975-04-15', 'American', 1),
(2, 'Emma', 'Johnson', '1980-08-20', 'British', 2),
(3, 'Michael', 'Williams', '1978-03-10', 'Canadian', 3),
(4, 'Sophia', 'Brown', '1982-11-25', 'Spanish', 4),
(5, 'David', 'Jones', '1979-07-03', 'French', 5),
(6, 'Emily', 'Taylor', '1984-04-12', 'German', 6),
(7, 'Daniel', 'Anderson', '1976-09-30', 'Italian', 7),
(8, 'Olivia', 'Martinez', '1981-12-18', 'Russian', 8),
(9, 'James', 'Garcia', '1974-02-05', 'Chinese', 9),
(10, 'Isabella', 'Lopez', '1986-06-22', 'Japanese', 10),
(11, 'William', 'Hernandez', '1977-08-07', 'Swedish', 11),
(12, 'Ava', 'Young', '1983-10-15', 'Australian', 12),
(13, 'Alexander', 'King', '1978-03-28', 'Mexican', 13),
(14, 'Mia', 'Scott', '1980-06-09', 'Dutch', 14),
(15, 'Ethan', 'Lewis', '1985-01-19', 'Belgian', 15),
(16, 'Charlotte', 'Wilson', '1979-04-27', 'Irish', 16),
(17, 'Ryan', 'Moore', '1984-09-02', 'Portuguese', 17),
(18, 'Sophie', 'Hill', '1978-12-11', 'Greek', 18),
(19, 'Benjamin', 'Walker', '1986-07-01', 'Turkish', 19),
(20, 'Amelia', 'Allen', '1981-05-14', 'Norwegian', 20),
(21, 'Samuel', 'Perez', '1976-11-28', 'Polish', 21),
(22, 'Chloe', 'Gonzalez', '1987-03-25', 'Finnish', 22),
(23, 'Joseph', 'Hernandez', '1979-02-08', 'Vietnamese', 23),
(24, 'Grace', 'Rivera', '1982-08-17', 'Thai', 24),
(25, 'Jacob', 'Mitchell', '1977-06-16', 'Malaysian', 25),
(26, 'Zoe', 'Carter', '1986-04-23', 'Singaporean', 1),
(27, 'Matthew', 'Torres', '1983-12-05', 'Indonesian', 2),
(28, 'Madison', 'Morris', '1980-10-30', 'Filipino', 23);


-- Inserting data into the Stadiums table
INSERT INTO Stadiums (stadium_id, stadium_name, location, capacity, home_team_id)
VALUES
(1, 'Alpha Stadium', 'New York', 50000, 1),
(2, 'Bravo Stadium', 'Los Angeles', 45000, 2),
(3, 'Charlie Arena', 'Chicago', 40000, 3),
(4, 'Delta Arena', 'Houston', 55000, 4),
(5, 'Echo Field', 'Phoenix', 60000, 5),
(6, 'Foxtrot Field', 'Philadelphia', 52000, 6),
(7, 'Golf Park', 'San Antonio', 47000, 7),
(8, 'Hotel Park', 'San Diego', 48000, 8),
(9, 'India Cricket Ground', 'Dallas', 43000, 9),
(10, 'Juliet Cricket Ground', 'San Jose', 42000, 10),
(11, 'Kilo Tennis Center', 'Austin', 41000, 11),
(12, 'Lima Tennis Center', 'Jacksonville', 40000, 12),
(13, 'Mike Stadium', 'Fort Worth', 39000, 13),
(14, 'November Stadium', 'Columbus', 38000, 14),
(15, 'Oscar Arena', 'Charlotte', 37000, 15),
(16, 'Papa Arena', 'San Francisco', 36000, 16),
(17, 'Quebec Arena', 'Indianapolis', 35000, 17),
(18, 'Romeo Arena', 'Seattle', 34000, 18),
(19, 'Sierra Hall', 'Denver', 33000, 19),
(20, 'Tango Hall', 'Washington', 32000, 20),
(21, 'Uniform Golf Course', 'Boston', 31000, 21),
(22, 'Victor Golf Course', 'Detroit', 30000, 22),
(23, 'Whiskey Pool', 'Nashville', 29000, 23),
(24, 'X-ray Pool', 'Memphis', 28000, 24),
(25, 'Yankee Track', 'Portland', 27000, 25),
(26, 'Zulu Stadium', 'Las Vegas', 26000, 1),
(27, 'Alpha Field', 'Louisville', 25000, 2),
(28, 'Bravo Park', 'Milwaukee', 24000, 8),
(29, 'Charlie Arena', 'Albuquerque', 23000, 9),
(30, 'Delta Park', 'Tucson', 22000, 20);

-- Inserting data into the Leagues table
INSERT INTO Leagues (league_id, league_name, sport, country, established_date)
VALUES
(1, 'Premier League', 'Football', 'England', '1992-02-20'),
(2, 'La Liga', 'Football', 'Spain', '1929-02-28'),
(3, 'Bundesliga', 'Football', 'Germany', '1963-07-28'),
(4, 'Serie A', 'Football', 'Italy', '1898-03-16'),
(5, 'Ligue 1', 'Football', 'France', '1932-09-11'),
(6, 'MLS', 'Football', 'United States', '1993-12-17'),
(7, 'NBA', 'Basketball', 'United States', '1946-06-06'),
(8, 'EuroLeague', 'Basketball', 'Europe', '1958-04-24'),
(9, 'NHL', 'Hockey', 'Canada', '1917-11-26'),
(10, 'KHL', 'Hockey', 'Russia', '2008-06-04'),
(11, 'IPL', 'Cricket', 'India', '2008-09-13'),
(12, 'BBL', 'Cricket', 'Australia', '2011-02-11'),
(13, 'MLB', 'Baseball', 'United States', '1903-02-02'),
(14, 'NPB', 'Baseball', 'Japan', '1950-11-30'),
(15, 'EPL', 'eSports', 'Global', '2011-06-15'),
(16, 'FIFA eWorld Cup', 'eSports', 'Global', '2004-07-09'),
(17, 'CS:GO Major Championships', 'eSports', 'Global', '2013-11-01'),
(18, 'Overwatch League', 'eSports', 'Global', '2017-12-06'),
(19, 'FIA Formula One World Championship', 'Auto Racing', 'Global', '1950-05-13'),
(20, 'MotoGP World Championship', 'Auto Racing', 'Global', '1949-06-17'),
(21, 'World Rugby Sevens Series', 'Rugby Sevens', 'Global', '1999-11-05'),
(22, 'World Surf League', 'Surfing', 'Global', '1976-11-09'),
(23, 'World Poker Tour', 'Poker', 'Global', '2002-03-30'),
(24, 'Professional Darts Corporation', 'Darts', 'Global', '1992-01-16'),
(25, 'PGA Tour', 'Golf', 'Global', '1929-01-17'),
(26, 'ATP Tour', 'Tennis', 'Global', '1972-01-01'),
(27, 'WTA Tour', 'Tennis', 'Global', '1970-06-21'),
(28, 'World Chess Championship', 'Chess', 'Global', '1886-03-11'),
(29, 'World Archery Championships', 'Archery', 'Global', '1931-08-08'),
(30, 'IAAF World Athletics Championships', 'Athletics', 'Global', '1983-08-07'),
(31, 'World Snooker Championship', 'Snooker', 'Global', '1927-04-18'),
(32, 'World Karate Championships', 'Karate', 'Global', '1970-10-17'),
(33, 'FIH Hockey World Cup', 'Hockey', 'Global', '1971-01-15'),
(34, 'FIVB Volleyball World Championships', 'Volleyball', 'Global', '1949-01-01'),
(35, 'ICC Cricket World Cup', 'Cricket', 'Global', '1975-06-07'),
(36, 'World Taekwondo Championships', 'Taekwondo', 'Global', '1973-05-28'),
(37, 'World Judo Championships', 'Judo', 'Global', '1956-05-26'),
(38, 'FIBA Basketball World Cup', 'Basketball', 'Global', '1950-10-22'),
(39, 'WBSA World Billiards Championship', 'Billiards', 'Global', '1870-01-01'),
(40, 'World Sailing Championships', 'Sailing', 'Global', '1968-08-01'),
(41, 'World Bridge Championships', 'Bridge', 'Global', '1960-01-01'),
(42, 'World Squash Championships', 'Squash', 'Global', '1976-10-04'),
(43, 'World Indoor Lacrosse Championship', 'Lacrosse', 'Global', '2003-01-01'),
(44, 'World Gymnastics Championships', 'Gymnastics', 'Global', '1903-03-21'),
(45, 'World Badminton Championships', 'Badminton', 'Global', '1977-05-01');


INSERT INTO Matches (match_id, date, location, home_team_id, away_team_id, winner_id, loser_id, tournament_id)
VALUES
(1, '2024-01-01', 'Stadium A', 1, 2, 1, 2, 1),
(2, '2024-01-01', 'Stadium B', 3, 4, 3, 4, 1),
(3, '2024-01-02', 'Stadium C', 5, 6, 5, 6, 1),
(4, '2024-01-02', 'Stadium D', 7, 8, 8, 7, 1),
(5, '2024-01-03', 'Stadium E', 9, 10, 9, 10, 1),
(6, '2024-01-03', 'Stadium F', 11, 12, 12, 11, 1),
(7, '2024-01-04', 'Stadium G', 13, 14, 13, 14, 1),
(8, '2024-01-04', 'Stadium H', 15, 16, 15, 16, 1),
(9, '2024-01-05', 'Stadium I', 17, 18, 17, 18, 1),
(10, '2024-01-05', 'Stadium J', 19, 20, 19, 20, 1),
(11, '2024-01-06', 'Stadium K', 21, 22, 21, 22, 1),
(12, '2024-01-06', 'Stadium L', 23, 24, 24, 23, 1),
(13, '2024-01-07', 'Stadium M', 25, 1, 25, 1, 1),
(14, '2024-01-07', 'Stadium N', 2, 3, 1, 1, 1),
(15, '2024-01-08', 'Stadium O', 4, 5, 4, 5, 1),
(16, '2024-01-08', 'Stadium P', 6, 7, 7, 6, 1),
(17, '2024-01-09', 'Stadium Q', 8, 9, 8, 9, 1),
(18, '2024-01-09', 'Stadium R', 10, 11, 11, 10, 1),
(19, '2024-01-10', 'Stadium S', 12, 13, 12, 13, 1),
(20, '2024-01-10', 'Stadium T', 14, 15, 15, 14, 1),
(21, '2024-01-11', 'Stadium U', 16, 17, 16, 17, 1),
(22, '2024-01-11', 'Stadium V', 18, 19, 19, 18, 1),
(23, '2024-01-12', 'Stadium W', 20, 21, 20, 21, 1),
(24, '2024-01-12', 'Stadium X', 22, 23, 23, 22, 1),
(25, '2024-01-13', 'Stadium Y', 24, 25, 24, 25, 1);


INSERT INTO [Statistics] (stat_id, match_id, athlete_id, goals_scored, assists, yellow_cards, red_cards) VALUES
(1, 1, 1, 3, 2, 0, 0),
(2, 2, 2, 1, 0, 1, 0),
(3, 3, 2, 0, 3, 2, 0),
(4, 4, 4, 2, 2, 0, 1),
(5, 5, 5, 1, 1, 0, 0),
(6, 6, 6, 4, 0, 1, 0),
(7, 7, 7, 0, 0, 0, 1),
(8, 8, 8, 2, 0, 2, 0),
(9, 9, 9, 3, 1, 1, 0),
(10, 10, 21, 1, 2, 0, 0),
(11, 11, 11, 0, 0, 2, 1),
(12, 12, 12, 1, 1, 1, 0),
(13, 13, 13, 2, 3, 0, 0),
(14, 14, 14, 1, 0, 0, 0),
(15, 15, 15, 0, 2, 1, 0),
(16, 16, 16, 3, 1, 0, 0),
(17, 17, 17, 2, 0, 0, 1),
(18, 18, 18, 0, 0, 3, 0),
(19, 19, 19, 1, 2, 0, 0),
(20, 20, 20, 0, 1, 2, 0),
(21, 21, 21, 4, 0, 0, 0),
(22, 22, 22, 0, 3, 1, 0),
(23, 23, 23, 1, 0, 0, 1),
(24, 24, 24, 0, 1, 0, 0),
(25, 25, 25, 3, 1, 2, 0);


INSERT INTO Standings (standings_id, league_id, team_id, position, points, tournament_id)
VALUES
(1, 1, 1, 1, 90, 1),
(2, 1, 2, 2, 85, 2),
(3, 1, 3, 3, 80, 3),
(4, 1, 4, 4, 75, 4),
(5, 1, 5, 5, 70, 5),
(6, 1, 6, 6, 65, 6),
(7, 1, 7, 7, 60, 7),
(8, 1, 8, 8, 55, 8),
(9, 1, 9, 9, 50, 9),
(10, 1, 10, 10, 45, 10),
(11, 2, 11, 1, 90, 11),
(12, 2, 12, 2, 85, 12),
(13, 2, 13, 3, 80, 13),
(14, 2, 14, 4, 75, 14),
(15, 2, 15, 5, 70, 15),
(16, 2, 16, 6, 65, 16),
(17, 2, 17, 7, 60, 17),
(18, 2, 18, 8, 55, 18),
(19, 2, 19, 9, 50, 19),
(20, 2, 20, 10, 45, 20),
(21, 3, 21, 1, 90, 21),
(22, 3, 22, 2, 85, 22),
(23, 3, 23, 3, 80, 23),
(24, 3, 24, 4, 75, 24),
(25, 3, 25, 5, 70, 25);

SELECT * FROM Athletes;
-- Display contents of the Teams table
SELECT * FROM Teams;
-- Display contents of the Matches table
SELECT * FROM Matches;
-- Display contents of the Tournaments table
SELECT * FROM Tournaments;
-- Display contents of the Statistics table
SELECT * FROM [Statistics];
-- Display contents of the Coaches table
SELECT * FROM Coaches;
-- Display contents of the Stadiums table
SELECT * FROM Stadiums;
-- Display contents of the Leagues table
SELECT * FROM Leagues;
-- Display contents of the Standings table
SELECT * FROM Standings;


