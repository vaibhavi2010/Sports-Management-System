/*
**Name: Mishwaben Rakeshkumar Patel and Vaibhavi Honagekar 
**Date: 04/25/2024
** History 
** Date Created    Comments 
** 01/21/2024      Creating Tables
** 01/28/2024      Populating Tables
** 02/04/2024      Create Views
** 02/09/2024      Scripting
** 02/18/2024      Stored Procedures
** 02/24/2024      User-Defined Functions
** 02/28/2024      Cursor
** 03/16/2024      Triggers
** 03/20/2024      Transaction
** 03/28/2024      Security
** 04/25/2024      Final Submission
*/

--Create the Audit Table
CREATE TABLE Teams_Audit (
    audit_id INT IDENTITY(1,1) PRIMARY KEY,
    team_id INT,
    team_name VARCHAR(100),
    sports VARCHAR(100),
    established_date DATE,
    coach_id INT,
    home_stadium VARCHAR(100),
    operation_type VARCHAR(10),  -- 'INSERT', 'UPDATE', 'DELETE'
    changed_on DATETIME
);

SELECT * FROM Teams_Audit;



--Trigger for INSERT
CREATE TRIGGER trg_after_insert_team
ON Teams
AFTER INSERT
AS
BEGIN
    INSERT INTO Teams_Audit (team_id, team_name, sports, established_date, coach_id, home_stadium, operation_type, changed_on)
    SELECT team_id, team_name, sports, established_date, coach_id, home_stadium, 'INSERT', GETDATE()
    FROM inserted;
END;

SELECT OBJECT_DEFINITION(OBJECT_ID('trg_after_insert_team'));

--Trigger for UPDATE
CREATE TRIGGER trg_after_update_team
ON Teams
AFTER UPDATE
AS
BEGIN
    INSERT INTO Teams_Audit (team_id, team_name, sports, established_date, coach_id, home_stadium, operation_type, changed_on)
    SELECT team_id, team_name, sports, established_date, coach_id, home_stadium, 'UPDATE', GETDATE()
    FROM inserted;
END;

SELECT OBJECT_DEFINITION(OBJECT_ID('trg_after_update_team'));

--Trigger for DELETE
CREATE TRIGGER trg_after_delete_team
ON Teams
AFTER DELETE
AS
BEGIN
    INSERT INTO Teams_Audit (team_id, team_name, sports, established_date, coach_id, home_stadium, operation_type, changed_on)
    SELECT team_id, team_name, sports, established_date, coach_id, home_stadium, 'DELETE', GETDATE()
    FROM deleted;
END;

SELECT OBJECT_DEFINITION(OBJECT_ID('trg_after_delete_team'));
