/*
**Name: Vaibhavi Honagekar and Mishwaben Rakeshkumar Patel
**Date: 04/25/2024
** History 
** Date Created    Comments 
** 01/21/2024      Creating Tables
** 01/28/2024      Populating Tables
** 02/04/2024      Create Views
** 02/09/2024      Scripting
** 02/18/2024      Stored Procedures
** 02/24/2024      User-Defined Functions
** 02/28/2024      Cursor
** 03/16/2024      Triggers
** 03/20/2024      Transaction
** 03/28/2024      Security
** 04/25/2024      Final Submission
*/

-- Drop the cursor if it exists
IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'CursorExample')
BEGIN
    DROP PROCEDURE CursorExample;
END
GO

-- Create the cursor
CREATE PROCEDURE CursorExample
AS
BEGIN
    -- Declare variables
    DECLARE @athlete_id INT;
    DECLARE @first_name VARCHAR(100);
    DECLARE @last_name VARCHAR(100);
    
    -- Declare cursor
    DECLARE athlete_cursor CURSOR FOR
    SELECT athlete_id, first_name, last_name FROM Athletes;
    
    -- Open the cursor
    OPEN athlete_cursor;
    
    -- Fetch the first row
    FETCH NEXT FROM athlete_cursor INTO @athlete_id, @first_name, @last_name;
    
    -- Loop through the cursor
    WHILE @@FETCH_STATUS = 0
    BEGIN
        -- Print information for the current row
        PRINT 'Athlete ID: ' + CAST(@athlete_id AS VARCHAR(10)) + ', Name: ' + @first_name + ' ' + @last_name;
        
        -- Fetch the next row
        FETCH NEXT FROM athlete_cursor INTO @athlete_id, @first_name, @last_name;
    END
    
    -- Close and deallocate the cursor
    CLOSE athlete_cursor;
    DEALLOCATE athlete_cursor;
END
GO

-- Execute the stored procedure to demonstrate the cursor
EXEC CursorExample;
GO

-- Drop the cursor
IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'CursorExample')
BEGIN
    DROP PROCEDURE CursorExample;
END
GO
