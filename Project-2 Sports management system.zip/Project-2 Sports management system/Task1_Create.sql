/*
**Name: Vaibhavi Honagekar and Mishwaben Rakeshkumar Patel
**Date: 04/25/2024
** History 
** Date Created    Comments 
** 01/21/2024      Creating Tables
** 01/28/2024      Populating Tables
** 02/04/2024      Create Views
** 02/09/2024      Scripting
** 02/18/2024      Stored Procedures
** 02/24/2024      User-Defined Functions
** 02/28/2024      Cursor
** 03/16/2024      Triggers
** 03/20/2024      Transaction
** 03/28/2024      Security
** 04/24/2024      Final Submission
*/

-- Create Teams table
CREATE TABLE Teams (
    team_id INT PRIMARY KEY,
    team_name VARCHAR(100) NOT NULL,
    sports VARCHAR(100) NOT NULL,
    established_date DATE NOT NULL,
    coach_id INT,
    home_stadium VARCHAR(100) NOT NULL
);

-- Create Athletes table
CREATE TABLE Athletes (
    athlete_id INT PRIMARY KEY,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    date_of_birth DATE NOT NULL,
    nationality VARCHAR(100) NOT NULL,
    team_id INT NOT NULL,
    FOREIGN KEY (team_id) REFERENCES Teams(team_id)
);
-- Create Tournaments table
CREATE TABLE Tournaments (
    tournament_id INT PRIMARY KEY,
    tournament_name VARCHAR(150) NOT NULL,
    sport VARCHAR(150) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL
);


-- Create Matches table
CREATE TABLE Matches (
    match_id INT PRIMARY KEY,
    date DATE NOT NULL,
    location VARCHAR(150) NOT NULL,
    home_team_id INT NOT NULL,
    away_team_id INT NOT NULL,
    winner_id INT NOT NULL,
    loser_id INT NOT NULL,
    tournament_id INT,
    FOREIGN KEY (home_team_id) REFERENCES Teams(team_id),
    FOREIGN KEY (away_team_id) REFERENCES Teams(team_id),
    FOREIGN KEY (winner_id) REFERENCES Teams(team_id),
    FOREIGN KEY (loser_id) REFERENCES Teams(team_id),
    FOREIGN KEY (tournament_id) REFERENCES Tournaments(tournament_id)
);


-- Create Statistics table
CREATE TABLE [Statistics] (
    stat_id INT PRIMARY KEY,
    match_id INT NOT NULL,
    athlete_id INT NOT NULL,
    goals_scored INT NOT NULL,
    assists INT NOT NULL,
    yellow_cards INT NOT NULL,
    red_cards INT NOT NULL,
    FOREIGN KEY (match_id) REFERENCES Matches(match_id),
    FOREIGN KEY (athlete_id) REFERENCES Athletes(athlete_id)
);

-- Create Coaches table
CREATE TABLE Coaches (
    coach_id INT PRIMARY KEY,
    first_name VARCHAR(150) NOT NULL,
    last_name VARCHAR(150) NOT NULL,
    date_of_birth DATE NOT NULL,
    nationality VARCHAR(150) NOT NULL,
    team_id INT NOT NULL,
    FOREIGN KEY (team_id) REFERENCES Teams(team_id)
);

-- Create Stadiums table
CREATE TABLE Stadiums (
    stadium_id INT PRIMARY KEY,
    stadium_name VARCHAR(150) NOT NULL,
    location VARCHAR(150) NOT NULL,
    capacity INT NOT NULL,
    home_team_id INT NOT NULL,
    FOREIGN KEY (home_team_id) REFERENCES Teams(team_id)
);

-- Create Leagues table
CREATE TABLE Leagues (
    league_id INT PRIMARY KEY,
    league_name VARCHAR(150) NOT NULL,
    sport VARCHAR(150) NOT NULL,
    country VARCHAR(50) NOT NULL,
    established_date DATE NOT NULL
);

-- Create Standings table
CREATE TABLE Standings (
    standings_id INT PRIMARY KEY,
    league_id INT NOT NULL,
    team_id INT NOT NULL,
    position INT NOT NULL,
    points INT NOT NULL,
    tournament_id INT,
    FOREIGN KEY (league_id) REFERENCES Leagues(league_id),
    FOREIGN KEY (team_id) REFERENCES Teams(team_id),
    FOREIGN KEY (tournament_id) REFERENCES Tournaments(tournament_id)
);

SELECT * FROM Athletes;
-- Display contents of the Teams table
SELECT * FROM Teams;
-- Display contents of the Matches table
SELECT * FROM Matches;
-- Display contents of the Tournaments table
SELECT * FROM Tournaments;
-- Display contents of the Statistics table
SELECT * FROM [Statistics];
-- Display contents of the Coaches table
SELECT * FROM Coaches;
-- Display contents of the Stadiums table
SELECT * FROM Stadiums;
-- Display contents of the Leagues table
SELECT * FROM Leagues;
-- Display contents of the Standings table
SELECT * FROM Standings;
